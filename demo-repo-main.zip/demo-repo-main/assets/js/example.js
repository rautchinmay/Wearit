
var x = function() {
	 console.log('foo');
}


var y = function(a, b) {
	return a == null;
};

