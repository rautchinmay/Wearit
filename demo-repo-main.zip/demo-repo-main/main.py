import hashlib

def main(foo):
	x = 10
